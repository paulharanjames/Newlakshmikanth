<form action="<?php echo esc_url( home_url( '/' ) ); ?>" id="searchform" method="get">
    <div>
        <input type="text" id="s" name="s" value="" />
        <input type="submit" value="<?php _e('Search','delicacy') ?>" id="searchsubmit" />
    </div>
</form>