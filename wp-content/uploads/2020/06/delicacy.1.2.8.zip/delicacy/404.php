<?php get_header(); ?>
	
    <div id="content">

		<h3 class="block-title"><?php _e('Page not found', 'delicacy') ?></h3>
        <p><?php _e('Try searching the site:', 'delicacy') ?></p>
		<?php get_search_form(); ?>

	</div><!-- end #content -->


	<?php get_sidebar(); ?>

	</div><!-- end #content-wrapper -->

<?php get_footer(); ?>
