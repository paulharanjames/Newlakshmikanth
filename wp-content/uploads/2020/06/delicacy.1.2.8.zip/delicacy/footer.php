	</div><!-- end #inner-wrapper -->
</div><!-- end #wrapper -->

		<div id="footer">
			<p>Copyright <?php echo delicacy_copy_date(); ?> <strong><a href="<?php echo home_url( '/' ); ?>"><?php bloginfo( 'name' ); ?></a></strong></p>
			
			<div id="site-generator">
			
				<small><?php _e('Proudly powered by', 'delicacy'); ?> <a href="http://wordpress.org" target="_blank"><?php _e('WordPress', 'delicacy'); ?></a>. <?php _e('Design by ', 'delicacy'); ?> <a href="http://webtuts.pl/" title="<?php _e('WebTuts.pl', 'delicacy'); ?>" target="_blank">WebTuts.pl</a></small>

			</div><!-- #site-generator -->
		</div>

	<?php wp_footer(); ?>
	
	<!-- Don't forget analytics -->
	
</body>

</html>
